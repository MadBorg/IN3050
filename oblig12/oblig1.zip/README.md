# Oblig 1

To run the code its recommended to use the jupyter notebooks program